"use strict";
alert('text!');