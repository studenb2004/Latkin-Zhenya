"use strict";
alert('text!'); // комментарий
/*
	комментарий
*/